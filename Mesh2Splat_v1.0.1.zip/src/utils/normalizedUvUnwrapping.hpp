#include "utils.hpp"
#include "../../thirdParty/xatlas/xatlas.h"


void generateNormalizedUvCoordinatesPerFace(int& uvSpaceWidth, int& uvSpaceHeight, std::vector<Mesh>& meshes);

void generateNormalizedUvCoordinatesPerFace(int& uvSpaceWidth, int& uvSpaceHeight, Mesh& meshes);